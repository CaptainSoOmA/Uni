public interface DBConnector {

	public String doQuery(String query);
}
