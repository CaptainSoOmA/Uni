
public class OfflineDB implements DBConnector {

	@Override
	public String doQuery(String query) {
		// hier nachschlagen
		return null;
	}

}
