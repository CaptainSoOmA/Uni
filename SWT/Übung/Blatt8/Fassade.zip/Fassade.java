
public class Fassade {

	// Referenzen auf verborgene Classen
	DBConnector onlien = new OnlineDB();
	DBConnector offline = new OfflineDB();
	
	String doQuery(String query){
		
		// sehr einfache version in der erst offlien nachgeschlagen wird
		// falls da nix ist online nachsehen
		
		String ofl = offline.doQuery(query);
		if (ofl != ""){
			return ofl;	
		} else {
			return onlien.doQuery(query);
		}
		
		// hier könnte auch noch eine Replikation eingebunden werden 
		// oder die sucheinträge könnten gemeinsam zurückgegben werden 
	}
}
