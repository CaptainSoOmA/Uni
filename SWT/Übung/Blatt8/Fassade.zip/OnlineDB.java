
public class OnlineDB implements DBConnector {

	@Override
	public String doQuery(String query) {
		// TODO Auto-generated method stub
		return null;
	}

}
