package binTree

type BinTree interface { //Binärbaum für U7 A2 (also nur benötigte Funktionalität)
		
		// Mit x ist jeweils das aufrufende Objekt gemeint.

		//Konstrucktor für leeren BinTree
		//NewTree() *Imp

		//Das übergebene Element ist an den Baum angefügt 
		//Int da im Rahmen der Übung einfacher, resultat daraus:
		//0 kann als Element nicht angefügt werden
		Insert(int)
		
		//true wenn Baum leer
		//false sonst
		IsEmpty() bool

		//0 wenn Baum leer
		//Anzahl der Blätter + Wurzel sonst
		GetSize() int

		//Preorder Travesierung ist auf dem übergebenen Kanal ausgegeben
		TravPreOrder(chan int)
		}
