package binTree

type (
	Imp struct {
		wurzel Node
		size   int
	}

	Node struct {
		value int
		left  *Node
		right *Node
	}
)

func NewTree() *Imp {
	x := new(Imp)
	return x
}

func (x *Imp) Insert(val int) {

	if val == 0 {
		print("Einfügen gescheitert: Ungültiger Wert\n")
	} else if x.wurzel.value == 0 {
		x.wurzel.value = val
		x.size++
	} else {
		act := &x.wurzel
		done := false

		tmp := new(Node)
		tmp.value = val

		for !done {

			if act.value > val {
				if act.left == nil {
					act.left = tmp
					x.size++
					done = true
				}
				act = act.left
			} else {
				if act.right == nil {
					act.right = tmp
					x.size++
					done = true
				}
				act = act.right
			}
		}
	}
}

func (x *Imp) IsEmpty() bool {
	return x.size == 0
}

func (x *Imp) GetSize() int{
	return x.size
}

func (x *Imp) TravPreOrder(c chan int) {
	preorder(&x.wurzel, c)
}

func preorder(x *Node, c chan int) {
	c <- x.value

	if x.left != nil {
		preorder(x.left, c)
	}

	if x.right != nil {
		preorder(x.right, c)
	}
}
