package main

import . "binTree"

//Gleichheit strikt nach Definition im Aufgabenblatt (also wenn beide
//leer oder paarweise Gleicheit nach PreOrder Travesierung)

func isEqual(equal chan bool, t *Imp, s *Imp, c1 chan int, c2 chan int) {
	if t.IsEmpty() && s.IsEmpty() {
		equal <- true
	} else if t.GetSize() != s.GetSize() {
		equal <- false
	} else {
		for i := 0; i < t.GetSize(); i++ {
			if <-c1 != <-c2 {
				equal <- false
				break
			}
		}
		equal <- true
	}
}

func main() {
	t := NewTree()
	s := NewTree()

	/*Ausgabe true*/

	/*t := NewTree()
	t.Insert(5)
	t.Insert(6)
	t.Insert(4)

	s := NewTree()

	Ausgabe false
	*/

	t.Insert(5)
	t.Insert(6)
	t.Insert(4)

	s.Insert(5)
	s.Insert(6)
	s.Insert(4)

	//Damit keine Synchronisation beim Senden stattfinden muss, buffered channels
	c1, c2, equal := make(chan int, t.GetSize()), make(chan int, t.GetSize()), make(chan bool)
	//Travesierung (Abweichend von der Aufgabe im Buch sparen wir den Schritt
	//den Baum zunächst in eine Folge zu schreiben aus, da dies schlich
	//einen Umweg, dessen Mehrwert sich nicht erschließen mag, darstellt
	go t.TravPreOrder(c1)
	go s.TravPreOrder(c2)

	//Simultaner paarweiser Vergleich
	go isEqual(equal, t, s, c1, c2)

	print(<-equal)
	print("\n")

}
