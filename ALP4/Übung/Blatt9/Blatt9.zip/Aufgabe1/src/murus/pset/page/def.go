package page

// (c) Christian Maurer   v. 120909 - license see murus.go

import
  . "murus/obj"
const (
  N = 2 // provisorial
)
type Page interface {

  Object
}
