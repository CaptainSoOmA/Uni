package puls

// (c) Christian Maurer   v. 130308 - license see murus.go


func Touch () {}
