package rob

// (c) Christian Maurer   v. 130102 - license see murus.go


func Touch () { }
