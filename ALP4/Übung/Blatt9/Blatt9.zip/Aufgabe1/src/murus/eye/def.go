package eye

// (c) Christian Maurer   v. 120216 - license see murus.go

// TODO
