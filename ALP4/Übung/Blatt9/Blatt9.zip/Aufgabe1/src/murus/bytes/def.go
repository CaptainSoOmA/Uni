package bytes

// (c) Christian Maurer   v. 120910 - license see murus.go

import
  . "murus/obj"
type
  ByteSequence interface { // completely worthless ?

  Object
}
