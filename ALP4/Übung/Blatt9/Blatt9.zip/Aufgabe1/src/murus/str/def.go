package str

// (c) Christian Maurer   v. 130302 - license see murus.go

//     latin-1-strings (without any bloody UTF-8-stuff)

// Returns true, iff s contains UTF8-runes.
func IsUTF8 (s *string) bool { return isUTF8(s) }

// Returns a string of n spaces.
func Clr (n uint) string { return clr(n) }

// s coincides with t up to certain UTF-8-runes (see constants in Z.go),
// that are changed to latin1-bytes.
func Set (s *string, t string) { set(s,t) }
func Lat1 (s *string) { lat1(s) }
// Invers to Lat1.
func UTF8 (s *string) { utf8(s) }

// Returns true, iff s has the form x{x|y}, where x = [A-Z]|[a-z], y = x|[0-9]|
func Lit (s string) bool { return lit(s) }

// If p < len(s), the byte at position p of s is replaced by c.
// Otherwise s is not changed.
func Replace (s *string, p uint, c byte) { replace (s,p,c) }

// Returns true, iff s contains no bytes or only spaces.
func Empty (s string) bool { return empty(s) }

// Returns a string of n 'c's.
func Const (c byte, n uint) string { return const_(c,n) }

// Returns the number of bytes of s without considering trailing spaces.
func ProperLen (s string) uint { return properLen(s) }

// Returns true, iff s and t coincide up to spaces at their ends,
// i.e. if they contains the same bytes in the same order,
// where spaces at their ends are not considered.
func QuasiEq (s, t string) bool { return quasiEq(s,t) }

// All/the first / small letter(s)/capital(s) of s are/is
// replaced by the corresponding capital(s)/small letter(s).
func ToUpper0 (s *string) { toUpper0(s) }
func ToLower0 (s *string) { toLower0(s) }
func ToUpper (s *string) { toUpper(s) }
func ToLower (s *string) { toLower(s) }

// Returns true, iff the first character of s is no letter or a capital 'A'..'Z'.
func Cap0 (s string) bool { return cap0(s) }

// Returns true, iff s and t are equal up to small letters vs. corresponding capitals.
func Equiv (s, t string) bool { return equiv(s,t) }

// Returns true, iff s and t are equal up to small letters
// vs. corresponding capitals and up to trailing spaces.
func QuasiEquiv (s, t string) bool { return quasiEquiv(s,t) }

// Returns true, iff s is lexicographically before t
// (particularly an empty string is Less than a nonempty one).
// Capitals are less than the corresponding small letters.
// TODO: The problem of the equivalences 'ä'/"ae", 'ö'/"oe",
// 'ü'/"ue", 'Ä'/'Ae', 'Ö'/"", 'Ü'/"Ue" and 'ß'/"ss" and 
// that of characters with "deadkeys" is not yet solved.
func Less (s, t string) bool { return less(s,t) }

// Returns true, iff s is lexicographically before t, where
// capitals and corresponding small letters are identified.
func QuasiLess (s, t string) bool { return quasiLess(s,t) }

// Returns true, iff c occurs in s.
// In this case p is the index of the first occurrence of c in s;
// otherwise p == len(s).
func Contains (s string, c byte, p *uint) bool { return contains(s,c,p) }

// Returns the position of c in s, if c occurs in s,
// returns otherwise uint(len (s)).
func Pos (s string, c byte) uint { return pos(s,c) }

// Returns true, iff c occurs in s up to small letters vs. corresponding
// capitals (hence e.g. for c = 'x', if 'X' occurs in s, and for c = 'X',
// if 'x' occurs in s). In this case p is the index of the first occurrence
// of the corresponding byte in s; otherwise p == len(s).
func QuasiContains (s string, c byte, p *uint) bool { return quasiContains(s,c,p) }

// Returns true, iff s is contained as connected part in t.
// In this case p is the position in t, at which s starts;
// otherwise p == len(t).
func IsPart (s, t string, p *uint) bool { return isPart (s,t,p) }

// Returns true, iff s is contained as connected part in t
// up to the difference of small letters to capitals.
// In this case p is the index in s, at which t starts;
// otherwise p == len(t).
func IsEquivPart (s, t string, p *uint) bool { return isEquivPart(s,t,p) }

// Returns true, iff s - after removing trailing spaces in it - is contained
// up to the difference of small letters to capitals as leading part in t.
func IsEquivPart0 (s, t string) bool { return isEquivPart0(s,t) }

// If p < len (s), the c is inserted in s as p-th character;
// otherwise c is appended at the end of s.
func Ins1 (s *string, c byte, p uint) { ins(s,string(c),p) }

// If p < len(s), then t is inserted into s, startig at position p,
// i.e. s consists of the first p bytes of s before, then t, and then
// the bytes of s starting at p; otherwise t is appended to s.
func Ins (s *string, t string, p uint) { ins(s,t,p) }

// If s contains at least p + n bytes, then n bytes, beginning
// at position p, otherwise all bytes, are removed from s.
// Otherwise s is unchanged.
func Rem (s *string, p, n uint) { rem(s,p,n) }

// Returns the string, consisting of the n bytes of s,
// beginning at position p, if s contains at least n bytes.
// If not, the result is correspondingly shorter.
func Part (s string, p, n uint) string { return part(s,p,n) }

// If len(s) > n, the bytes from position n on are removed from s;
// if len(s) < n, s is filled up with trailing spaces to length n.
// In case len(s) == n, nothing is changed.
func Norm (s *string, n uint) { norm(s,n) }

// As far as existent, trailing spaces are removed from s.
func RemSpaces (s *string) { remSpaces(s) }

// As far as existent, all spaces are removed from s.
func RemAllSpaces (s *string) { remAllSpaces(s) }

// As far as existent, for left resp. !left leading resp. trailing spaces
// are removed from s and s is filled up with spaces on the other side
// to its former length.
func Move (s *string, left bool) { move(s,left) }

// TODO Spec
func InsSpace (s *string, p uint) { insSpace(s,p) }

// TODO Spec
func Shift (s *string, p uint) { shift(s,p) }

// If n >= len(*s), then *s is on its left and right equally filled up with spaces,
// otherwise *s is cut down to length n.
func Center (s *string, n uint) { center(s,n) }

// All nondigits are removed from s; the digits are shifted to the left
// and s is filled up with spaces to its original length.
func RemAllNondigits (s *string) { remAllNondigits(s) }

// Returns the number of all connected strings (= strings without spaces) in s,
// those strings and their start positions in s.
func Words (s string) (uint, []string, []uint) { return words(s) }

// A linefeed (byte(10)) is appended to s.
func AppendLF (s *string) { appendLF(s) }

// Returns the leading part of *s until (excluding) the first byte b with b < ' ';
// from *s now that part and all leading bytes b with b < ' ' are removed.
func SplitLine (s *string) string { return splitLine(s) }
