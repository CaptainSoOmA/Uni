package rw

// (c) Christian Maurer   v. 120910 - license see murus.go

const (
  reader = iota
  writer
)
const (
  rIn = iota
  rOut
  wIn
  wOut
)
