package lr

// (c) Christian Maurer   v. 120215 - license see murus.go

const (
  left = iota
  right
)
const (
  lIn = iota
  lOut
  rIn
  rOut
)
