package fuday

// (c) Christian Maurer   v. 130306 - license see murus.go


func Touch () { }
