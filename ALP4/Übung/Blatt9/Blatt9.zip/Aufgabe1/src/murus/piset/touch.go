package piset

// (c) Christian Maurer   v. 120909 - license see murus.go


func Touch () { }
