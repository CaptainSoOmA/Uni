package pair

// (c) Christian Maurer   v. 130104 - license see murus.go

import
  . "murus/obj"
type
  Pair interface {

  Object

  Name () string
  Typ () byte
}
