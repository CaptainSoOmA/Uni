package netz

// (c) Christian Maurer   v. 130118 - license see murus.go

func StartUndZielGewählt () bool { return gewählt() }

func KürzestenWegSuchen () { suchen() }
