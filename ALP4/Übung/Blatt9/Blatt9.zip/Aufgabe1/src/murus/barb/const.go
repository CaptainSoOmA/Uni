package barb

// (c) Christian Maurer   v. 130424 - license see murus.go

const (
  customer = iota
  barber
)
