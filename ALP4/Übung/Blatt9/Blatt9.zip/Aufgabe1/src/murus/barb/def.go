package barb

// (c) Christian Maurer   v. 130424 - license see murus.go

type
  Barber interface {
  Customer ()
  Barber ()
}
