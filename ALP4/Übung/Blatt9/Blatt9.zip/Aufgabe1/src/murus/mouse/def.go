package mouse

// (c) Christian Maurer   v. 120710 - license see murus.go

// >>> This package only serves the implementations of murus/kbd 
//     and murus/scr; it must not no be used elsewhere.

type Command byte
