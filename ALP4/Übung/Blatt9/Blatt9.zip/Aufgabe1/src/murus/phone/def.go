package phone

// (c) Christian Maurer   v. 120909 - license see murus.go

import
  . "murus/obj"
type
  PhoneNumber interface {

  Editor
  Stringer
  Printer
}
