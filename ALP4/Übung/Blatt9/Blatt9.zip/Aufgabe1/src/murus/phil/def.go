package phil

// (c) Christian Maurer   v. 130526 - license see murus.go

import
  . "murus/lockp"
type
  Philos interface {

  LockerP
}
