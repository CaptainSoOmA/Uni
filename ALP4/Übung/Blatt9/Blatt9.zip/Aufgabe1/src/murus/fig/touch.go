package fig

// (c) Christian Maurer   v. 121217 - license see murus.go


func Touch () { }
