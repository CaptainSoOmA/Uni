package audio

// (c) Christian Maurer   v. 130115 - license see murus.go

import
  . "murus/obj"
type
  Audio interface {

  Indexer
}
