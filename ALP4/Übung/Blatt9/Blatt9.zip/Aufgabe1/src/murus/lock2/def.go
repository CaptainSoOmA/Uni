package lock2

// (c) Christian Maurer   v. 120910 - license see murus.go

import
  . "murus/lockp"
type
  Locker2 interface {

  LockerP // only for values p < 2
}
