package scr

// (c) Christian Maurer   v. 120909 - license see murus.go

import
  "murus/xker"


func writeGlx () {
//
  if underX {
    xker.WriteGlx()
  }
}
