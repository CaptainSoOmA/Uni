export GOPATH=`pwd`
go run afg1.go
